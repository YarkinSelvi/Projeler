import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# 📂 Temizlenmiş veri setini yükle
file_path = r"C:\Users\Lenovo\Desktop\cleaned_diabetes_dataset.csv"
df = pd.read_csv(file_path)

# 🎯 Bağımsız değişkenler (X) ve bağımlı değişken (Y)
X = df.drop(columns=["Diabetes_012"])  # Girdi değişkenleri
Y = df["Diabetes_012"]  # Hedef değişken

# 🔄 Veriyi Eğitim (%80) ve Test (%20) olarak ayırma
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42, stratify=Y)

# 🔍 Normalizasyon (Opsiyonel: Eğer gerekliyse)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ✅ İşlenmiş veriyi kaydetme (Opsiyonel)
pd.DataFrame(X_train_scaled).to_csv(r"C:\Users\Lenovo\Desktop\X_train_scaled.csv", index=False)
pd.DataFrame(X_test_scaled).to_csv(r"C:\Users\Lenovo\Desktop\X_test_scaled.csv", index=False)
pd.DataFrame(Y_train).to_csv(r"C:\Users\Lenovo\Desktop\Y_train.csv", index=False)
pd.DataFrame(Y_test).to_csv(r"C:\Users\Lenovo\Desktop\Y_test.csv", index=False)

print("✅ Veri eğitim ve test setlerine ayrıldı ve ölçeklendirildi!")

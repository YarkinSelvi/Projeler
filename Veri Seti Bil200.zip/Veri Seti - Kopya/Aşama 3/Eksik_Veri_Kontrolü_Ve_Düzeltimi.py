import pandas as pd

# 📂 Birleştirilmiş dosyayı yükle
file_path = r"C:\Users\Lenovo\Desktop\merged_diabetes_dataset.csv"
df = pd.read_csv(file_path)

# 🔍 1. Eksik veri kontrolü
missing_values = df.isnull().sum()
print("📌 Eksik Veri Sayıları:\n", missing_values)

# 🔄 Eksik verileri doldurma (opsiyonel: kaldırma veya ortalama ile doldurma)
df = df.dropna()  # Eksik verisi olan satırları sil

# 🔍 2. Aykırı değerleri kontrol etme
print("\n📌 İstatistiksel Dağılım:")
print(df.describe())

# BMI için aykırı değer tespiti
Q1 = df["BMI"].quantile(0.25)
Q3 = df["BMI"].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

df = df[(df["BMI"] >= lower_bound) & (df["BMI"] <= upper_bound)]

# 🔍 3. Kategorik verileri düzenleme
df["Diabetes_012"] = df["Diabetes_012"].astype(int)  # Kesinlikle tam sayı olmalı

# 📂 Temizlenmiş veri setini kaydetme
cleaned_file_path = r"C:\Users\Lenovo\Desktop\cleaned_diabetes_dataset.csv"
df.to_csv(cleaned_file_path, index=False)

print(f"\n✅ Veri temizlendi ve kaydedildi: {cleaned_file_path}")

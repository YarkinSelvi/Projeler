import pandas as pd
import os

# Veri setlerinin bulunduğu yollar
dataset1_path = "C:/Users/Lenovo/Desktop/Dataset1/archive/"
dataset2_path = "C:/Users/Lenovo/Desktop/Dataset2/"
dataset3_path = "C:/Users/Lenovo/Desktop/Dataset3/archive/"

# CSV dosyalarını oku
df1 = pd.read_csv(os.path.join(dataset1_path, "diabetes_012_health_indicators_BRFSS2015.csv"))
df2 = pd.read_csv(os.path.join(dataset1_path, "diabetes_binary_5050split_health_indicators_BRFSS2015.csv"))
df3 = pd.read_csv(os.path.join(dataset1_path, "diabetes_binary_health_indicators_BRFSS2015.csv"))
df4 = pd.read_csv(os.path.join(dataset3_path, "diabetes_dataset.csv"))

# Excel dosyalarını oku
df5 = pd.read_excel(os.path.join(dataset2_path, "BDHS_DDC_2011.xlsx"))
df6 = pd.read_excel(os.path.join(dataset2_path, "BDHS_DDC_2017_2018.xlsx"))

# Sütun isimlerini yazdır
print("Dataset 1 kolonları:", df1.columns)
print("Dataset 2 kolonları:", df2.columns)
print("Dataset 3 kolonları:", df3.columns)
print("Dataset 4 kolonları:", df4.columns)
print("Dataset 5 kolonları:", df5.columns)
print("Dataset 6 kolonları:", df6.columns)

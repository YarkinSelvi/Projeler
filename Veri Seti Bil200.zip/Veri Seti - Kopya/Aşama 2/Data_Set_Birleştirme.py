import pandas as pd
import os

# 📂 Dosya yolları
file1 = r"C:\Users\Lenovo\Desktop\Dataset1\archive\diabetes_012_health_indicators_BRFSS2015.csv"
file2 = r"C:\Users\Lenovo\Desktop\Dataset1\archive\diabetes_binary_5050split_health_indicators_BRFSS2015.csv"
file3 = r"C:\Users\Lenovo\Desktop\Dataset1\archive\diabetes_binary_health_indicators_BRFSS2015.csv"

# 📌 Veri setlerini oku
df1 = pd.read_csv(file1)
df2 = pd.read_csv(file2)
df3 = pd.read_csv(file3)

# 🔄 Dataset 2 ve 3 için Diabetes sütununu `Diabetes_012` formatına dönüştür
df2["Diabetes_012"] = df2["Diabetes_binary"].apply(lambda x: 1 if x == 1 else 0)
df3["Diabetes_012"] = df3["Diabetes_binary"].apply(lambda x: 1 if x == 1 else 0)

# ❌ Gereksiz `Diabetes_binary` sütununu kaldır
df2.drop(columns=["Diabetes_binary"], inplace=True)
df3.drop(columns=["Diabetes_binary"], inplace=True)

# 🔄 Tüm veri setlerini birleştir
merged_df = pd.concat([df1, df2, df3], ignore_index=True)

# 📂 Yeni dosyaya kaydet
output_file = r"C:\Users\Lenovo\Desktop\merged_diabetes_dataset.csv"
merged_df.to_csv(output_file, index=False)

print(f"✅ Veri setleri başarıyla birleştirildi! Kaydedildi: {output_file}")
